package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HomePage {
    WebDriver driver;

    // Constructor
    public HomePage(WebDriver driver) {
        this.driver = driver;
    }

    // Locator for the search bar
    By searchBar = By.xpath("//input[@id='search']");

    // Locator for a product (just an example)
    By productLink = By.xpath("//img[@alt='Balboa Persistence Tee']");

    // Method to enter text in the search bar
    public void enterSearchText(String searchQuery) {
        driver.findElement(searchBar).sendKeys(searchQuery);
    }

    // Method to submit search
    public void submitSearch() {
        driver.findElement(searchBar).submit();
    }

    // Method to navigate to a product
    public void navigateToProduct() {
        driver.findElement(productLink).click();
        //Select Size
        driver.findElement(By.xpath("//div[@id='option-label-size-143-item-170']")).click();
        //Select colour
        driver.findElement(By.xpath("//div[@id='option-label-color-93-item-53']"));
        
    }

	public void searchProduct(String string) {
		// TODO Auto-generated method stub
		
	}
}

