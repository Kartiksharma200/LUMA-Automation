package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class CartPage {
    WebDriver driver;

    // Constructor
    public CartPage(WebDriver driver) {
        this.driver = driver;
    }

    // Locator for the "Add to Cart" button
    By addToCartButton = By.xpath("//a[@class='action showcart']");

    // Method to click the "Add to Cart" button
    public void addToCart() {
        driver.findElement(addToCartButton).click();
    }
}

