package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ProductPage {
    WebDriver driver;

    // Constructor
    public ProductPage(WebDriver driver) {
        this.driver = driver;
    }

    // Locator for the "Add to Cart" button
    By addToCartButton = By.id("product-addtocart-button");

    // Locator for the product price (example)
    By productPrice = By.className("price");

    // Method to click the "Add to Cart" button
    public void addProductToCart() {
        driver.findElement(addToCartButton).click();
    }

    // Method to get the product price
    public String getProductPrice() {
        return driver.findElement(productPrice).getText();
    }
}
