package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class CheckoutPage {
    WebDriver driver;

    // Constructor
    public CheckoutPage(WebDriver driver) {
        this.driver = driver;
    }

    // Locator for the checkout button
    By checkoutButton = By.xpath("//button[@id='top-cart-btn-checkout']");

    // Method to go to checkout
    public void proceedToCheckout() {
        driver.findElement(checkoutButton).click();
    }

    // Locator for payment method selection
    By paymentMethodOptions = By.className("payment-method");

    // Method to verify available payment methods
    public boolean isPaymentMethodAvailable() {
        return driver.findElements(paymentMethodOptions).size() > 0;
    }
}
