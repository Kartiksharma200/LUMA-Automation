package testRunner;

import io.cucumber.testng.CucumberOptions;
import io.cucumber.testng.AbstractTestNGCucumberTests;

@CucumberOptions(
    features = "src/main/resources/features", // Path to your feature files
    glue = {"stepDefinitions"}, // Path to your step definition classes
    plugin = {"pretty", "html:target/cucumber-reports.html", "json:target/cucumber-reports.json"}
)
public class TestRunner extends AbstractTestNGCucumberTests {
}
