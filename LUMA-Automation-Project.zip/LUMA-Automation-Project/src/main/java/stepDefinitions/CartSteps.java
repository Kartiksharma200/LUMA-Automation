package stepDefinitions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import pageObjects.HomePage;
import pageObjects.CartPage;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;

public class CartSteps {
    WebDriver driver;
    HomePage homePage;
    CartPage cartPage;

    @Given("I navigate to the product page")
    public void navigateToProductPage() {
        driver = new ChromeDriver();
        driver.get("https://magento.softwaretestingboard.com/");
        homePage = new HomePage(driver);
    }

    @When("I add the product to the cart")
    public void addProductToCart() {
        homePage.searchProduct("T-shirt");
        cartPage = new CartPage(driver);
        cartPage.addToCart();
    }

    @Then("I should see the product in my cart")
    public void verifyProductInCart() {
        // Add a check for the cart content, like verifying the cart item
    }
}
